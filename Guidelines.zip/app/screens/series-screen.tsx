import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router";
import { SeriesCard } from "../components/series-card";
import { TVInstructions } from "../components/tv-instructions";
import { TVSearchBox } from "../components/tv-search-box";
import { series } from "../data/mock-data";
import { ArrowLeft } from "lucide-react";

export function SeriesScreen() {
  const navigate = useNavigate();
  const [focusedIndex, setFocusedIndex] = useState(-1); // Start at search box
  const [searchQuery, setSearchQuery] = useState("");
  const COLUMNS = 6;

  const filteredSeries = useMemo(() => {
    if (!searchQuery.trim()) return series;
    return series.filter((item) =>
      item.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If in search box
      if (focusedIndex === -1) {
        switch (e.key) {
          case "ArrowDown":
            e.preventDefault();
            if (filteredSeries.length > 0) {
              setFocusedIndex(0);
            }
            break;
          case "Backspace":
          case "Escape":
            if (!searchQuery) {
              e.preventDefault();
              navigate("/");
            }
            break;
        }
      } else {
        // In grid
        switch (e.key) {
          case "ArrowLeft":
            e.preventDefault();
            setFocusedIndex((prev) => Math.max(0, prev - 1));
            break;
          case "ArrowRight":
            e.preventDefault();
            setFocusedIndex((prev) =>
              Math.min(filteredSeries.length - 1, prev + 1)
            );
            break;
          case "ArrowUp":
            e.preventDefault();
            const newUpIndex = focusedIndex - COLUMNS;
            if (newUpIndex < 0) {
              setFocusedIndex(-1); // Back to search
            } else {
              setFocusedIndex(newUpIndex);
            }
            break;
          case "ArrowDown":
            e.preventDefault();
            setFocusedIndex((prev) =>
              Math.min(filteredSeries.length - 1, prev + COLUMNS)
            );
            break;
          case "Backspace":
          case "Escape":
            e.preventDefault();
            navigate("/");
            break;
          case "Enter":
            e.preventDefault();
            console.log("Selected series:", filteredSeries[focusedIndex]);
            break;
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [focusedIndex, searchQuery, filteredSeries, navigate]);

  return (
    <div className="min-h-screen bg-zinc-950 p-12">
      <TVInstructions />
      <div className="max-w-[1600px] mx-auto">
        <div className="flex items-center gap-6 mb-8">
          <button
            onClick={() => navigate("/")}
            className="text-zinc-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-8 h-8" />
          </button>
          <h1 className="text-5xl font-bold text-white">Series</h1>
        </div>

        <div className="mb-8">
          <TVSearchBox
            value={searchQuery}
            onChange={setSearchQuery}
            focused={focusedIndex === -1}
            onFocus={() => setFocusedIndex(-1)}
            placeholder="Search series..."
          />
        </div>

        {filteredSeries.length > 0 ? (
          <div className="grid grid-cols-6 gap-6">
            {filteredSeries.map((item, index) => (
              <SeriesCard
                key={item.id}
                title={item.title}
                seasons={item.seasons}
                posterUrl={item.posterUrl}
                focused={focusedIndex === index}
                onFocus={() => setFocusedIndex(index)}
                onClick={() =>
                  console.log("Clicked series:", filteredSeries[focusedIndex])
                }
              />
            ))}
          </div>
        ) : (
          <div className="text-center text-zinc-500 text-2xl py-20">
            No series found
          </div>
        )}
      </div>
    </div>
  );
}
